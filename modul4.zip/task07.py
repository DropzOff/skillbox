print('Задача 7. Хватит ли зарплаты')

hours = int(input("Введите отработанные часы: "))
credit_balance = int(input("Введите остаток по кредиту: "))
food_expenses = int(input("Введите траты на еду: "))

salary = hours * 100

if salary >= credit_balance + food_expenses:
    print("Часов хватает. Можно отдохнуть.")
else:
    print("Часов не хватает. Придётся работать больше!")
