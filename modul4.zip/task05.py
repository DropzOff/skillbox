print('Задача 5. Модуль числа')

x = int(input('Введите число x: '))
print(f'|x| = |{x}| = {abs(x)}')
